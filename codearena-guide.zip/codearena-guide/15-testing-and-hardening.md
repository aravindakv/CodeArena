# 15 · Testing, load, and hardening

## The test pyramid you now have

| Level | Command | Covers |
| --- | --- | --- |
| Unit | `./gradlew test` | key loading, example parsing, comparators, verdict rules, streaks |
| Integration (Testcontainers) | `./gradlew :services:contest-service:test` | the real Lua script on real Redis |
| Sandbox red team | `./gradlew :services:judge-worker:test -Psandbox` | 11 attacks and failures against the real sandbox |
| Ingestion logic | `cd ingestion && uv run pytest` | example checks, brute-force cross-check, dedupe |
| Seed data | `scripts/py.sh scripts/seed.py --check` | every example, reference vs brute force |
| End to end | `scripts/smoke.sh` | the whole platform through the gateway, as user and admin |
| Load | `k6 run load/fest.js` | a fest on your machine |

## Malicious code: what each attack meets

| Attack | Stopped by | Verdict |
| --- | --- | --- |
| `while True: pass` | per-run `timeout`, outer wall clock | TIME_LIMIT_EXCEEDED |
| Fork bomb | `--pids-limit=128` | RUNTIME_ERROR |
| Allocate gigabytes | `--memory`, no swap | MEMORY_LIMIT_EXCEEDED |
| Open a socket, call home, read cloud metadata | `--network=none` | RUNTIME_ERROR |
| Write to `/etc`, fill the disk | read-only root, 64 MB tmpfs, `fsize` limit | RUNTIME_ERROR |
| Print forever | 64 KB output cap | OUTPUT_LIMIT_EXCEEDED |
| Read the expected answers | never mounted; only inputs enter the container | wrong answer |
| Exploit the kernel / escape | gVisor user-space kernel, no capabilities, non-root | contained |
| Crash the judge repeatedly | SQS retries, SYSTEM_ERROR after 3 attempts, DLQ | judge stays up |
| Flood submissions | gateway rate limit, 1/s per user | 429 |

## Load test a fest locally

**File:** `load/fest.js`

```javascript
// Local fest simulation with k6 (https://k6.io): many users polling the leaderboard and submitting.
// Scale it to your machine: the judge, not the API, is the bottleneck on one laptop.
//   scripts/py.sh load/make_users.py 200        # creates users once and writes load/users.json
//   k6 run -e CONTEST=<id> -e VUS=200 load/fest.js
// setup() logs every user in (about one a second, the gateway's per-IP login limit), so tokens are fresh.
import http from "k6/http";
import { check, sleep } from "k6";
import { SharedArray } from "k6/data";

const BASE = __ENV.BASE || "http://localhost:9080/api/v1";
const CONTEST = __ENV.CONTEST;
const VUS = Number(__ENV.VUS || 100);
const users = new SharedArray("users", () => JSON.parse(open("./users.json")));

const SOLUTION = `class Solution:
    def pairWithTargetSum(self, nums, target):
        first = {}
        for j, x in enumerate(nums):
            if target - x in first:
                return [first[target - x], j]
            first.setdefault(x, j)
`;

export const options = {
  setupTimeout: "15m",   // logging in 200 users at the login rate limit takes a few minutes
  scenarios: {
    fest: { executor: "ramping-vus", startVUs: 0, stages: [
      { duration: "1m", target: VUS }, { duration: "3m", target: VUS }, { duration: "30s", target: 0 }] },
  },
  thresholds: {
    "http_req_duration{name:leaderboard}": ["p(95)<200"],
    "http_req_failed{name:leaderboard}": ["rate<0.01"],
    "checks{name:submit}": ["rate>0.95"],
  },
};

function login(u) {
  for (;;) {
    const r = http.post(`${BASE}/auth/login`, JSON.stringify(u), { headers: { "Content-Type": "application/json" },
      tags: { name: "setup" } });
    if (r.status === 200) return r.json("accessToken");
    if (r.status !== 429) throw new Error(`login ${u.email}: ${r.status} ${r.body}`);
    sleep(1.1);   // rate limited: wait for the bucket to refill
  }
}

export function setup() {
  if (!CONTEST) throw new Error("pass -e CONTEST=<contest id> (create one in the admin console)");
  const c = http.get(`${BASE}/contests/${CONTEST}`, { tags: { name: "setup" } });
  if (c.status !== 200) throw new Error(`contest ${CONTEST}: ${c.status} ${c.body}`);
  const n = Math.min(users.length, VUS);
  console.log(`logging in ${n} users (about one a second)...`);
  const tokens = [];
  for (let i = 0; i < n; i++) {
    const token = login(users[i]);
    const r = http.post(`${BASE}/contests/${CONTEST}/register`, null,
      { headers: { Authorization: `Bearer ${token}` }, tags: { name: "setup" } });
    if (r.status !== 204 && r.status !== 200) throw new Error(`register for contest: ${r.status} ${r.body}`);
    tokens.push(token);
  }
  return { tokens };
}

let reported = false;   // print the first failed submission of each VU, so a failure explains itself

export default function (data) {
  const token = data.tokens[(__VU - 1) % data.tokens.length];
  const auth = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
  // A competitor refreshes the board every 5 s and submits about once a minute.
  for (let i = 0; i < 12; i++) {
    const lb = http.get(`${BASE}/contests/${CONTEST}/leaderboard`, { tags: { name: "leaderboard" } });
    check(lb, { "leaderboard 200": (r) => r.status === 200 });
    if (i === 0) {
      const r = http.post(`${BASE}/submissions`, JSON.stringify({ slug: "pair-with-target-sum", lang: "python",
        mode: "SUBMIT", code: SOLUTION, contestId: CONTEST }), { headers: auth, tags: { name: "submit" } });
      const ok = check(r, { "submit accepted or rate limited": (x) => x.status === 202 || x.status === 429 }, { name: "submit" });
      if (!ok && !reported) { reported = true; console.warn(`submit failed: ${r.status} ${r.body}`); }
    }
    sleep(5);
  }
}
```

**File:** `load/make_users.py`

```python
#!/usr/bin/env python3
"""Creates N load-test users through the gateway and writes their logins to load/users.json.
k6 logs them in itself at the start of each test (load/fest.js setup), so tokens are always fresh; access tokens
expire after 15 minutes. The gateway limits register/login per IP, so this paces itself (about one user a second).

    scripts/py.sh load/make_users.py 100
"""
import json
import sys
import time
from pathlib import Path

import requests

API = "http://localhost:9080/api/v1"
PASSWORD = "load-test-password"
n = int(sys.argv[1]) if len(sys.argv) > 1 else 100
users = []
for i in range(n):
    email = f"load{i}@codearena.local"
    while True:
        r = requests.post(f"{API}/auth/register", json={"email": email, "password": PASSWORD, "displayName": f"load_{i}"})
        if r.status_code == 429:          # rate limited: wait for the bucket to refill
            time.sleep(1.1)
            continue
        if r.status_code not in (200, 201, 409):   # 409 = already exists from an earlier run, which is fine
            sys.exit(f"\nregister {email} failed: {r.status_code} {r.text[:200]}")
        break
    users.append({"email": email, "password": PASSWORD})
    print(f"\r{i + 1}/{n}", end="", flush=True)
    time.sleep(1.05)   # the per-IP limit refills one request per second
out = Path(__file__).parent / "users.json"
out.write_text(json.dumps(users))
print(f"\nwrote {out}")
```

```bash
sudo snap install k6                                   # or see https://k6.io/docs/get-started/installation/
scripts/py.sh load/make_users.py 100                   # once, ~2 minutes: the register rate limit paces it
# Admin console → Fests → create one starting now with pair-with-target-sum; copy its id
k6 run -e CONTEST=<id> -e VUS=100 load/fest.js
```

k6 first logs each user in and registers them for the fest (about one per second, because of the gateway's login
limit), so 100 users add under two minutes before the load starts. Tokens are fresh for every run. If a submission
fails, k6 prints the first failing response (`submit failed: 403 ...`), which names the cause: fest not started yet,
`pair-with-target-sum` not in the fest, or a service down.

What to look for: leaderboard p95 under 200 ms no matter how many virtual users (it is one Redis GET), submissions
accepted or rate-limited but never failing, and the judge queue draining (watch http://localhost:9707). On one machine
the judge is the bottleneck: raise `JUDGE_CONCURRENCY` up to your CPU count and watch the queue age fall.

## Hardening checklist before anything leaves your machine

- [ ] `BOOTSTRAP_ADMIN_EMAIL` is empty; admins are granted only in the console.
- [ ] `JUDGE_RUNTIME=runsc` everywhere user code runs.
- [ ] `COOKIE_SECURE=true` behind HTTPS.
- [ ] The JWT key comes from a secret store, with a fixed `kid` and a rotation plan (publish two keys in JWKS during rotation).
- [ ] `/internal/**` reachable only from inside the cluster (network policy), never routed by the gateway.
- [ ] Problem statements are sanitized on render (`rehype-sanitize`), because generated content is untrusted.
- [ ] Dependency and image scanning in CI (for example `trivy fs .` and `trivy image codearena/runner-python:1`).
- [ ] The red-team suite runs in CI on a host with gVisor.
