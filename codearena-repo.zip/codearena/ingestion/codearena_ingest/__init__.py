"""CodeArena AI + RAG ingestion worker (admin-triggered)."""
